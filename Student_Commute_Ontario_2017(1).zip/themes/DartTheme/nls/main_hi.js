// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DartTheme/nls/strings":{_themeLabel:"\u0921\u093e\u0930\u094d\u091f \u0925\u0940\u092e",_layout_default:"\u0921\u093f\u095e\u0949\u0932\u094d\u091f \u0930\u0942\u092a\u0930\u0947\u0916\u093e",_localized:{}}});