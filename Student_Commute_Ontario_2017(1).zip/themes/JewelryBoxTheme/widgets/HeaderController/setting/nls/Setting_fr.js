// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/widgets/HeaderController/setting/nls/strings":{group:"Nom",openAll:"Tout ouvrir dans le volet",dropDown:"Afficher dans le menu d\u00e9roulant",noGroup:"Aucun groupe de widgets n\u2019est d\u00e9fini.",groupSetLabel:"D\u00e9finir les propri\u00e9t\u00e9s des groupes de widgets",_localized:{}}});