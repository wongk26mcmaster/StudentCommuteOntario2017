// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/setting/nls/strings":{group:"Nama",openAll:"Buka Semua dalam Panel",dropDown:"Tampilkan di Menu Drop-down",noGroup:"Tidak ada aturan grup widget.",groupSetLabel:"Tetapkan properti grup widget",_localized:{}}});