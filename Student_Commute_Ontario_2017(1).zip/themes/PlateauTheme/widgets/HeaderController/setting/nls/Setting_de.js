// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/setting/nls/strings":{group:"Name",openAll:"Alle im Bereich \u00f6ffnen",dropDown:"In Dropdown-Men\u00fc anzeigen",noGroup:"Es wurde keine Widget-Gruppe festgelegt.",groupSetLabel:"Eigenschaften f\u00fcr Widget-Gruppen festlegen",_localized:{}}});