// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/nls/strings":{_themeLabel:"Tem\u0103 platou",_layout_default:"Configura\u0163ie implicit\u0103",_layout_layout1:"Aspectul 1",_localized:{}}});